import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
// import { NewProductComponent } from './new-product/new-product.component'
import { UpsComponent } from './ups/ups.component'
//import { EditProductComponent } from './edit-product/edit-product.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { ProductGuard } from  './product.guard'
// import { CalComponent } from './cal/cal.component';
// import { TabComponent } from './tab/tab.component';


const routes: Routes = [
  {path:'',component:ProductListComponent},
  // {path:'/h',component:TabComponent},
  // {path:'add',component:NewProductComponent,canActivate:[ProductGuard]},
  {path:'ups',component:UpsComponent,canActivate:[ProductGuard]},
  //{path:"edit",component:EditProductComponent},
  {path :"signup",component:SignupComponent},
  {path:"login",component:LoginComponent}
  // {path:"calculater",component:CalComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

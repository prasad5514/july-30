import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ProductListComponent } from './product-list/product-list.component';
// import { NewProductComponent } from './new-product/new-product.component';
//import { NewUpsComponent } from './new-ups/new-ups.component';
//import { EditProductComponent } from './edit-product/edit-product.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { ProductGuard }  from './product.guard';
// import { CalComponent } from './cal/cal.component';
import { UpsComponent } from './ups/ups.component';
// import { TableComponent } from './table/table.component';
// import { TabComponent } from './tab/tab.component';
//import { TestComponent } from './test/test.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ProductListComponent,
    // NewProductComponent,
    //NewUpsComponent,
    //EditProductComponent,
    SignupComponent,
    LoginComponent,
    // CalComponent,
    UpsComponent
    // TableComponent,
    // TabComponent,
    //TestComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ProductGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service'
import { Router } from '@angular/router'
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  title:String="login"
email=""
password=""
showerr: boolean=false;
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit(): void {
  }

  login(){
    //console.log(this.email)
    this.userService.loginUser(this.email,this.password).subscribe(res=>{
      //alert("login")
      localStorage.setItem('token',res['token'])

      this.router.navigate(['/'])
    },
    
   err=>{
     alert("wrong creditials")
    this.router.navigate(['/signup'])
  // this.showerr=true;
   //console.log(this.showerr)

  
  }
    
    )
   
    
  }

}

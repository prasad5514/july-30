import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree,Router } from '@angular/router';
import { ProductService } from './product.service'
import { Observable, from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductGuard implements CanActivate {
  constructor(private _product:ProductService,private _router:Router){

  }
  canActivate():boolean{
    if(this._product.loggedIn()){
      console.log(true)
      return true;
    }
    else{
      this._router.navigate(['/login'])
        return false

    }
  }
  
}

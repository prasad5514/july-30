import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

//import { ProModel } from './product-list/product.model';
//import { empModel } from './new-product/ups.model';
import { empModel } from './ups/ups.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
pid=""
editItem=<any>[]
  //constructor(private http:HttpClient) { }
  // getProducts(){
  //   return this.http.get('http://localhost:3000/products');
  // }
  // newProduct(item){
  // return this.http.post("http://localhost:3000/insert",{"product":item})
  // .subscribe(data=>{
  //   console.log(data)
  // })
  // }

  // deleteProduct(id){
  //  // return this.http.post("http://localhost:3000/delete",{"id":id})
  //   return this.http.post("http://localhost:3000/delete",{"pid":id})
  
  // }

  /*editProduct(id){
    return this.http.post("http://localhost:3000/edit",{"pid":id})
  }*/

  update(item){
    console.log("inside service")
    return this.http.post("http://localhost:3000/update",{"product":item,"pid":this.pid})
    .subscribe(data=>{
      console.log(data)
    })
    }

     loggedIn(){
    return !!localStorage.getItem('token')
  }

  //begnning
  readonly baseURL1 = 'http://localhost:3000/products';
  //created object(http) of HttpClient
  constructor( private http:HttpClient ) { }
  //products:ProModel[];
  getProducts(){
    return this.http.get("http://localhost:3000/products");
  }
  newProduct(item){  //item is product filled by the user 
    return this.http.post("http://localhost:3000/insert",{"product2":item})//attaching the item,we are naming it as product
    .subscribe(data=>{console.log(data)})
  }


 
  //readonly baseURL = 'http://localhost:3001/employees';
  postProduct(emp2: empModel) {  //adding one
    return this.http.post(this.baseURL1, emp2);
  }

  getProductList() {    //displayfull
    return this.http.get(this.baseURL1);
  }

  putProduct(emp4: empModel) {  //edit
    return this.http.put(this.baseURL1 + `/${emp4._id}`, emp4);
  }

  deleteProduct(_id: string) {   //delete
    return this.http.delete(this.baseURL1 + `/${_id}`);
  }


}

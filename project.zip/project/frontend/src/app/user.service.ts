import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  register(user){
    return this.http.post("http://localhost:3000/register",{"user2":user})
    .subscribe(data=>{
      console.log(data)
    })
    }

  loginUser(email,password){
    return this.http.post("http://localhost:3000/login",{"email2":email,"password2":password})
  }
}

import { Component, OnInit } from '@angular/core';
import { UserModel } from './user.model';
import { UserService  } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  title:string="Registration"
  constructor(private userService:UserService,private router:Router) { }
  user=new UserModel(null,null,null,null,null,null)
  ngOnInit(): void {
  }

  register(){
    
    this.userService.register(this.user);
    console.log("called")
    alert("success")
    this.router.navigate(['/'])
  }

}

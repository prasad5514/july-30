export class UserModel{
    constructor(
        public fullname:string,
        public companyname:string,
        public location:string,
        public phonenumber:number,
        public email:string,
        public password:string
        
    ){}
}

import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ProductService } from '../product.service';  
import { empModel } from './ups.model';
declare var M: any;

@Component({
  selector: 'app-ups',
  templateUrl: './ups.component.html',
  styleUrls: ['./ups.component.css'],
  providers: [ProductService]
})
export class UpsComponent implements OnInit {

  constructor(public productService: ProductService) { }
  emp6=new empModel;
  emp7:empModel[];

  ngOnInit() {
    this.resetForm();
    this.refreshProductList();
  }

  resetForm(form?: NgForm) {
    if (form)
      form.reset();
        this.emp6={
      _id: "",
      desk: null,
      lap: null,
      swipe: null,
      scan: null,
      light: null,
      hour: null,
      future: null,
      kva: null,
      upsprice: null,
      battery: null,
      batteryprice: null
    }
  }

  ConvertToInt(val){
   return parseInt(val);
 }
 ConvertToFloat(val){
   return parseFloat(val);
 }
// ConvertToInt( ((emp6.productId)*200)+((emp6.productNumber)*100)+((emp6.productCode)*25)+((emp6.releaseDate)*1000)+((emp6.description)*20) ) }}
  

  onSubmit(form: NgForm) {
    if (form.value._id == "") {
      this.productService.postProduct(form.value).subscribe((res) => {
        //this.employeeService.newProduct(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshProductList();
        M.toast({ html: 'Saved successfully', classes: 'rounded' });
      });
    }
    else {
      this.productService.putProduct(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshProductList();
        M.toast({ html: 'Updated successfully', classes: 'rounded' });
      });
    }
  }

  refreshProductList() {
    this.productService.getProductList().subscribe((data) => {   //res=data
      //this.employeeService.employees = res as empModel[];
      this.emp7=JSON.parse(JSON.stringify(data));
    });
  }

  onEdit(emp8: empModel) {
    // this.employeeService.selectedEmployee = emp;
    this.emp6 = emp8;
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.productService.deleteProduct(_id).subscribe((res) => {
        this.refreshProductList();
        this.resetForm(form);
        M.toast({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }

  // onDelete(_id:string,form: NgForm){
  //   this.employeeService.deleteEmployee(_id).subscribe((res)=>{
  //     this.refreshEmployeeList();
  //   })
  // }
  // onDelete(_id:string){
  //   this.employeeService.deleteEmployee(_id).subscribe((res)=>{
  //     this.refreshEmployeeList();
  //   })
  // }

  // productItem=new ProModel(null,null,null,null,null,null,null,null);
  // AddProduct(){
  //   this.employeeService.newProduct(this.productItem);//we are passing productItem to newProduct function
  //   console.log("Called");
  //   alert("Success");
  //   //this.router.navigate(['/']);
  // }

//  title:String="Add Product"

//   constructor(private productService:ProductService,private router:Router) { }

//    productItem=new ProductModel(null,null,null,null,null,null,null,null,null)
//   ngOnInit(): void {
//   }

//   Addproduct(){
//     this.productService.newProduct(this.productItem);
//     console.log("called")
//     alert("successfully Added!")
//     this.router.navigate(['/'])
//   }


}

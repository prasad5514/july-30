export class empModel {
    _id: string;
    desk: number;
    lap: number;
    swipe: number;
    scan: number;
    light: number;
    hour: number;
    future: number;
    kva: number;
    upsprice:number;
    battery: number;
    batteryprice: number;
}

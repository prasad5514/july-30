const express =require('express');
const ProductData=require('../model/Productdata');
const Userdata=require('../model/userdata');
var router=express.Router();
var ObjectId = require('mongoose').Types.ObjectId;
const jwt=require('jsonwebtoken')


router.get('/products',function(req,res){
    res.header("access-Control-Allow-Origin","*")
    res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
    ProductData.find()
    .then(function(products){
        res.send(products);
    })
})
    
    router.post('/insert',function(req,res){
        res.header("Access-Control-Allow-Origin","*")
        res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
        console.log(req.body);
        var product3={
            desk:req.body.product2.desk,
            lap:req.body.product2.lap,
            swipe:req.body.product2.swipe,
            scan:req.body.product2.scan,
            light:req.body.product2.light,
            hour:req.body.product2.hour,
            future:req.body.product2.future,
            kva:req.body.product2.kva,
            upsprice:req.body.product2.upsprice,
            battery:req.body.product2.upsprice,
            batteryprice:req.product2.batteryprice
        }
        var product4=new ProductData(product3);
        product4.save();
    });

    router.post('/products', (req, res) => {  //add one employee detail
        var emp1 = new ProductData({
            desk: req.body. desk,
            lap: req.body.lap,
            swipe: req.body.swipe,
            scan: req.body.scan,
            light: req.body.light,
            hour: req.body.hour,
            future: req.body.future,
            kva: req.body.kva,
            upsprice: req.body.upsprice,
            battery: req.body.battery,
            batteryprice: req.body.batteryprice
        });
        emp1.save((err, doc) => {
            if (!err) { res.send(doc); }
            else { console.log('Error in Employee Save :' + JSON.stringify(err, undefined, 2)); }
        });
    });
    
    router.put('/products/:id', (req, res) => {          //edit
        if (!ObjectId.isValid(req.params.id))
            return res.status(400).send(`No record with given id : ${req.params.id}`);
    
        var emp3 = {
            desk: req.body.desk,
            lap: req.body.lap,
            swipe: req.body.swipe,
            scan: req.body.scan,
            light: req.body.light,
            hour: req.body.hour,
            future: req.body.future,
            kva: req.body.kva,
            upsprice: req.body.upsprice,
            battery: req.body.battery,
            batteryprice: req.body.batteryprice
        };
        ProductData.findByIdAndUpdate(req.params.id, { $set: emp3 }, { new: true }, (err, doc) => {
            if (!err) { res.send(doc); }
            else { console.log('Error in Employee Update :' + JSON.stringify(err, undefined, 2)); }
        });
    });

    router.delete('/products/:id', (req, res) => {  //delete
        if (!ObjectId.isValid(req.params.id))
            return res.status(400).send(`No record with given id : ${req.params.id}`);
    
        ProductData.findByIdAndRemove(req.params.id, (err, doc) => {
            if (!err) { res.send(doc); }
            else { console.log('Error in Employee Delete :' + JSON.stringify(err, undefined, 2)); }
        });
    });

    router.post('/register',function(req,res){
        res.header("Access-Control-Allow-Origin", "*")
        res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS")
        console.log("register");
        console.log(req.body)
        var user3={
            fullname:req.body.user2.fullname,
            companyname:req.body.user2.companyname,
            location:req.body.user2.location,
            phonenumber:req.body.user2.phonenumbe,
            email:req.body.user2.email,
            password:req.body.user2.password
        
        }
        var user4=new Userdata(user3)
        user4.save();
        
    });
    
    router.post('/login',function(req,res){
        res.header("Access-Control-Allow-Origin", "*")
        res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS")
        username=req.body.email2;
        password=req.body.password2;
        Userdata.findOne({ $and : [{ 'email' :  username },{ 'password' : password} ]})
       
        .then(function(user){
            if(user){
    
                //res.send(user)
                console.log("login"+user)
                let payload={subject:user._id}
                let token=jwt.sign(payload,'secretKey')
                 res.send({token})
                 
            }
            else{
                res.send("invalid")
                console.log("invalid"+user)
               
            }
           
        })
        
    })

    
    module.exports=router;
const mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/ProductDb',function(err){
    if(err){
        console.log(err);
    }
    else{
        console.log("connected:from userdata")
    }
});
const Schema=mongoose.Schema;

var newUserSchema=new Schema({
    fullname:String,
    companyname:String,
    location:String,
    phonenumber:Number,
    email:String,
    password:String
},{ collection: 'user' });

var Userdata=mongoose.model('user',newUserSchema);


module.exports=Userdata;